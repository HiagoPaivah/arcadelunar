import Desk from "./desk";
import { sessionUser, REFRESH_COOKIE } from "../lib/backend";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
export const dynamic = "force-dynamic";
export default async function Page() {
  const user = await sessionUser();
  if (!user && (await cookies()).get(REFRESH_COOKIE)?.value) redirect("/api/auth/refresh?return_to=/");
  return <Desk signedIn={!!user} />;
}
