import { z } from "zod";
import { HttpError, requireUser, rpc, supabase, assertOrigin, json, type AuthUser } from "../../../../lib/backend";
import { ticketInput, updateInput, messageInput, permissionInput, MAX_FILE_BYTES, allowedMimes, type Attachment } from "../../../../lib/domain";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;
async function body(request: Request) {
  const text = await request.text();
  if (text.length > 24000) throw new HttpError(413,"A mensagem é muito grande.");
  try { return JSON.parse(text); } catch { throw new HttpError(400,"Dados inválidos. Revise o formulário."); }
}
async function upload(id: number, request: Request, user: AuthUser) {
  if (Number(request.headers.get("content-length") || 0) > MAX_FILE_BYTES + 20000) throw new HttpError(413,"Cada arquivo pode ter até 3 MB.");
  if (!request.headers.get("content-type")?.startsWith("multipart/form-data")) throw new HttpError(400,"Envie o arquivo pelo formulário de anexos.");
  const form = await request.formData(); const file = form.get("file");
  if (!(file instanceof File)) throw new HttpError(400,"Escolha um arquivo.");
  if (!file.size || file.size > MAX_FILE_BYTES) throw new HttpError(413,"Envie um arquivo de até 3 MB.");
  if (!allowedMimes.includes(file.type)) throw new HttpError(400,"Use PNG, JPG, WEBP ou PDF.");
  const internal = form.get("internal") === "true"; const asRequester = form.get("asRequester") === "true";
  const check = await rpc<{version:number}>("upload_check",user,{id,internal,asRequester});
  const bytes = new Uint8Array(await file.arrayBuffer()); const head = new TextDecoder().decode(bytes.slice(0,12));
  const valid = file.type === "image/png" ? bytes[0]===137 && head.slice(1,4)==="PNG" : file.type === "image/jpeg" ? bytes[0]===255 && bytes[1]===216 && bytes[2]===255 : file.type === "image/webp" ? head.startsWith("RIFF") && head.slice(8,12)==="WEBP" : head.startsWith("%PDF-");
  if (!valid) throw new HttpError(400,"O conteúdo não corresponde ao formato informado.");
  const fileId = crypto.randomUUID(); const storageKey = "tickets/"+id+"/"+fileId;
  const name = file.name.replace(/[\r\n\\/\x00-\x1f]/g,"_").slice(0,180);
  const response = await supabase("/storage/v1/object/lunar-attachments/"+storageKey,{method:"POST",headers:{"Content-Type":file.type,"x-upsert":"false"},body:bytes},true);
  if (!response.ok) throw new HttpError(503,"Não foi possível anexar. Confira o bucket lunar-attachments no Supabase.");
  try { return json(await rpc<Attachment>("attachment_save",user,{id,version:check.version,fileId,storageKey,name,mime:file.type,size:file.size,internal,asRequester}),201); }
  catch (e) {
    await supabase("/storage/v1/object/lunar-attachments",{method:"DELETE",body:JSON.stringify({prefixes:[storageKey]})},true).catch(()=>{});
    throw e;
  }
}
async function handle(request: Request): Promise<Response> {
  try {
    const url = new URL(request.url); const path = url.pathname.replace(/^\/api\/support\/?/,"").split("/").filter(Boolean);
    if (request.method !== "GET") assertOrigin(request);
    const user = await requireUser(); const method = request.method;
    if (method === "GET" && path[0] === "me" && path.length===1) return json(await rpc("me",user));
    if (method === "GET" && path[0] === "members" && path.length===1) return json(await rpc("members",user));
    if (path[0] === "team" && path.length===1) {
      if (method === "GET") return json(await rpc("team_get",user));
      if (method === "POST") return json(await rpc("team_save",user,permissionInput.parse(await body(request))));
    }
    if (path[0] === "attachments" && path[1] && path.length===2 && method==="GET") {
      if (!z.string().uuid().safeParse(path[1]).success) throw new HttpError(404,"Anexo não encontrado.");
      const file = await rpc<{storageKey:string;name:string;mime:string}>("attachment_get",user,{id:path[1]});
      const response = await supabase("/storage/v1/object/authenticated/lunar-attachments/"+file.storageKey,{},true);
      if (!response.ok) throw new HttpError(404,"Arquivo não encontrado.");
      return new Response(response.body,{headers:{"Content-Type":file.mime,"Content-Disposition":"attachment; filename*=UTF-8''"+encodeURIComponent(file.name),"X-Content-Type-Options":"nosniff","Cache-Control":"private, no-store"}});
    }
    if (path[0] === "tickets" && path.length===1) {
      if (method==="GET") return json(await rpc("tickets_list",user));
      if (method==="POST") return json(await rpc("ticket_create",user,ticketInput.parse(await body(request))),201);
    }
    if (path[0] === "tickets" && path[1]) {
      const id = Number(path[1]); if (!Number.isSafeInteger(id) || id<1) throw new HttpError(404,"Chamado não encontrado.");
      if (path.length===2 && method==="GET") return json(await rpc("ticket_get",user,{id}));
      if (path.length===2 && method==="PATCH") return json(await rpc("ticket_update",user,{id,...updateInput.parse(await body(request))}));
      if (path.length===3 && path[2]==="messages" && method==="POST") return json(await rpc("message_create",user,{id,...messageInput.parse(await body(request))}));
      if (path.length===3 && path[2]==="attachments" && method==="POST") return await upload(id,request,user);
    }
    throw new HttpError(404,"Endereço não encontrado.");
  } catch (e) {
    if (e instanceof z.ZodError) return json({error:e.issues[0]?.message ?? "Revise os dados."},400);
    if (e instanceof HttpError) return json({error:e.message},e.status);
    return json({error:"Não foi possível completar a ação. Tente novamente."},500);
  }
}
export const GET=handle; export const POST=handle; export const PATCH=handle;
