import { z } from "zod";
import { cookies } from "next/headers";
import { HttpError, supabase, writeSession, clearSession, ACCESS_COOKIE, assertOrigin, json, type AuthSession } from "../../../../lib/backend";
export const runtime="nodejs";
export const dynamic="force-dynamic";
export const maxDuration=60;
const credentials=z.object({email:z.string().trim().email(),password:z.string().min(8).max(128),name:z.string().trim().min(2).max(100).optional(),token:z.string().max(6000).optional()});
function authError(data: {error_code?:string;code?:string;msg?:string}) {
  const code=data.error_code ?? data.code;
  if (code==="invalid_credentials") return "E-mail ou senha incorretos.";
  if (code==="email_not_confirmed") return "Confirme seu e-mail antes de entrar.";
  if (code==="user_already_exists") return "Já existe uma conta com este e-mail.";
  if (code==="over_email_send_rate_limit" || code==="over_request_rate_limit") return "Aguarde alguns minutos antes de tentar novamente.";
  if (code==="weak_password") return "Escolha uma senha mais forte.";
  return "Não foi possível concluir. Confira os dados e tente novamente.";
}
export async function POST(request:Request) {
  try {
    assertOrigin(request); const action=new URL(request.url).pathname.split("/").pop();
    if (action==="logout") {
      const access=(await cookies()).get(ACCESS_COOKIE)?.value;
      if(access) await supabase("/auth/v1/logout?scope=local",{method:"POST",headers:{Authorization:"Bearer "+access}}).catch(()=>{});
      await clearSession(); return json({ok:true});
    }
    const raw=await request.text(); if(raw.length>10000) throw new HttpError(413,"Dados muito grandes.");
    let data:unknown; try{data=JSON.parse(raw);}catch{throw new HttpError(400,"Dados inválidos.");}
    if(action==="recover"){
      const input=z.object({email:z.string().trim().email()}).parse(data);
      const response=await supabase("/auth/v1/recover?redirect_to="+encodeURIComponent(new URL("/reset-password",request.url).href),{method:"POST",body:JSON.stringify({email:input.email})});
      if(!response.ok) throw new HttpError(400,"Não foi possível enviar a recuperação. Aguarde e tente novamente.");
      return json({message:"Se houver uma conta com esse e-mail, enviaremos um link de recuperação."});
    }
    if(action==="password"){
      const input=z.object({token:z.string().min(20).max(6000),password:z.string().min(8).max(128)}).parse(data);
      const check=await supabase("/auth/v1/user",{headers:{Authorization:"Bearer "+input.token}});
      if(!check.ok) throw new HttpError(401,"O link expirou. Solicite a recuperação novamente.");
      const response=await supabase("/auth/v1/user",{method:"PUT",headers:{Authorization:"Bearer "+input.token},body:JSON.stringify({password:input.password})});
      if(!response.ok) throw new HttpError(400,"Não foi possível alterar a senha.");
      await clearSession();return json({message:"Senha alterada. Entre com sua nova senha."});
    }
    const input=credentials.parse(data);
    if(action==="login"){
      const response=await supabase("/auth/v1/token?grant_type=password",{method:"POST",body:JSON.stringify({email:input.email,password:input.password})});
      const result=await response.json();
      if(!response.ok) throw new HttpError(400,authError(result));
      await writeSession(result as AuthSession); return json({signedIn:true});
    }
    if(action==="register"){
      if(!input.name) throw new HttpError(400,"Informe seu nome.");
      const response=await supabase("/auth/v1/signup?redirect_to="+encodeURIComponent(new URL("/login",request.url).href),{method:"POST",body:JSON.stringify({email:input.email,password:input.password,data:{full_name:input.name}})});
      const result=await response.json();
      if(!response.ok) throw new HttpError(400,authError(result));
      if(result.access_token){await writeSession(result as AuthSession);return json({signedIn:true});}
      return json({message:"Cadastro recebido. Confira seu e-mail para confirmar a conta e depois entre com sua senha."},201);
    }
    throw new HttpError(404,"Ação não encontrada.");
  }catch(e){
    if(e instanceof z.ZodError)return json({error:e.issues[0]?.message ?? "Revise os dados."},400);
    if(e instanceof HttpError)return json({error:e.message},e.status);
    return json({error:"Não foi possível completar a ação."},500);
  }
}
