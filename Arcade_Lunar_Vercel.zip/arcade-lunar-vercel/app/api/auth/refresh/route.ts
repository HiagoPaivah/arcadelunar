import { redirect } from "next/navigation";
import { clearSession, refreshSession } from "../../../../lib/backend";
export const dynamic="force-dynamic";
export async function GET(request:Request) {
  const next=new URL(request.url).searchParams.get("return_to") || "/";
  const base=new URL(request.url); const destination=new URL(next,base);
  const safe=next.startsWith("/") && destination.origin===base.origin && !destination.pathname.startsWith("/api/auth") ? destination.pathname+destination.search : "/";
  try { if(await refreshSession()) redirect(safe); } catch(e) {
    if(e instanceof Error && "digest" in e) throw e;
  }
  await clearSession();redirect("/login");
}
