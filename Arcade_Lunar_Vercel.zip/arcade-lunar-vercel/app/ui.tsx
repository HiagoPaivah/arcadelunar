"use client";
import { useEffect, useId, useRef, type ReactNode } from "react";
import { X, Radio, Users, Bug, KeyRound, Lightbulb, Inbox, ArrowUp, Minus, ArrowDown, Flame } from "lucide-react";
import { initials, statusLabels, priorityLabels, type Category, type Priority as PriorityType, type Status } from "../lib/domain";
export function Avatar({ name, small = false }: { name: string; small?: boolean }) { return <span className={`avatar ${small ? "small" : ""}`} aria-hidden="true">{initials(name)}</span>; }
export function StatusBadge({ status }: { status: Status }) { return <span className={`status-badge ${status}`}><span />{statusLabels[status]}</span>; }
export function PriorityBadge({ priority }: { priority: PriorityType }) { const Icon = priority === "urgente" ? Flame : priority === "alta" ? ArrowUp : priority === "baixa" ? ArrowDown : Minus; return <span className={`priority-badge ${priority}`}><Icon size={13} />{priorityLabels[priority]}</span>; }
export function CategoryIcon({ category, size = 20 }: { category: Category; size?: number }) { const Icon = { conta: KeyRound, lives: Radio, comunidade: Users, bug: Bug, sugestao: Lightbulb }[category]; return <Icon size={size} strokeWidth={1.6} />; }
export function EmptyState({ title, text, action }: { title: string; text: string; action?: ReactNode }) { return <div className="empty-state"><span className="empty-icon"><Inbox size={29} strokeWidth={1.4} /></span><h3>{title}</h3><p>{text}</p>{action}</div>; }
export function Modal({ title, subtitle, children, onClose, wide = false }: { title: string; subtitle?: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null); const id = useId();
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); const before = document.body.style.overflow; document.body.style.overflow = "hidden"; return () => { dialog?.close(); document.body.style.overflow = before; }; }, []);
  return <dialog ref={ref} className={`modal ${wide ? "wide" : ""}`} aria-labelledby={id} onCancel={e => { e.preventDefault(); onClose(); }} onClick={e => { if (e.target === e.currentTarget) { const rect = e.currentTarget.getBoundingClientRect(); if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) onClose(); } }}><header className="modal-header"><div><h2 id={id}>{title}</h2>{subtitle && <p>{subtitle}</p>}</div><button className="icon-button" onClick={onClose} aria-label="Fechar janela"><X size={20} /></button></header>{children}</dialog>;
}
export function relativeTime(time: number, now = Date.now()) { const minutes = Math.max(0, Math.floor((now - time) / 60000)); return minutes < 1 ? "agora" : minutes < 60 ? `há ${minutes} min` : minutes < 1440 ? `há ${Math.floor(minutes / 60)} h` : `há ${Math.floor(minutes / 1440)} d`; }
export function dateTime(time: number) { return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" }).format(time); }
export function formatDuration(ms: number) { const minutes = Math.round(ms / 60000); return minutes < 60 ? `${minutes} min` : minutes < 1440 ? `${(minutes / 60).toFixed(1).replace(".", ",")} h` : `${(minutes / 1440).toFixed(1).replace(".", ",")} d`; }
