import { redirect } from "next/navigation";
import { sessionUser } from "../../lib/backend";
import LoginForm from "./form";
export const dynamic="force-dynamic";
export default async function LoginPage(){if(await sessionUser())redirect("/");return <LoginForm/>;}
