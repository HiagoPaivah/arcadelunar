import test from "node:test";
import assert from "node:assert/strict";
import { canRead, canHandle, canEscalate, canAssign, ticketInput, updateInput, messageInput } from "../lib/domain.ts";
const member = role => ({ id: role, email: role + "@test.invalid", name: role, role, createdAt: 0 });
test("Clients can read only their own tickets", () => {
  assert.equal(canRead(member("cliente"), { requesterId: "cliente" }), true);
  assert.equal(canRead(member("cliente"), { requesterId: "someone-else" }), false);
});
test("Staff can handle only their assigned specialty; administrator can handle all", () => {
  for (const queue of ["sac", "moderacao", "tecnico"]) {
    assert.equal(canHandle(member(queue), { queue }), true);
    assert.equal(canHandle(member("cliente"), { queue }), false);
    assert.equal(canHandle(member("admin"), { queue }), true);
  }
  assert.equal(canHandle(member("sac"), { queue: "tecnico" }), false);
});
test("Escalation follows SAC to moderation to technical", () => {
  assert.equal(canEscalate(member("sac"), "sac", "moderacao"), true);
  assert.equal(canEscalate(member("sac"), "sac", "tecnico"), false);
  assert.equal(canEscalate(member("moderacao"), "moderacao", "tecnico"), true);
  assert.equal(canEscalate(member("sac"), "moderacao", "tecnico"), false);
  assert.equal(canEscalate(member("tecnico"), "tecnico", "sac"), true);
  assert.equal(canEscalate(member("cliente"), "sac", "moderacao"), false);
});
test("Assignment cannot place clients or another specialty in a queue", () => {
  assert.equal(canAssign(member("sac"), "sac"), true);
  assert.equal(canAssign(member("sac"), "moderacao"), false);
  assert.equal(canAssign(member("cliente"), "sac"), false);
  assert.equal(canAssign(member("admin"), "tecnico"), true);
});
test("Submission validation rejects blank or incomplete tickets", () => {
  const valid = { key: "18e91a61-b6f2-412f-892c-dd1a6575d92c", title: "  Não consigo acessar  ", description: "  O acesso não funciona no meu aparelho.  ", category: "conta" };
  assert.equal(ticketInput.parse(valid).title, "Não consigo acessar");
  assert.equal(ticketInput.safeParse({ ...valid, description: "   " }).success, false);
  assert.equal(ticketInput.safeParse({ ...valid, category: "unknown" }).success, false);
});
test("Mutations require a positive version and a nonempty reply", () => {
  assert.equal(updateInput.safeParse({ version: -1, queue: "tecnico" }).success, false);
  assert.equal(messageInput.safeParse({ version: 1, body: "   " }).success, false);
  assert.equal(messageInput.parse({ version: 2, body: "Resposta" }).internal, false);
});
