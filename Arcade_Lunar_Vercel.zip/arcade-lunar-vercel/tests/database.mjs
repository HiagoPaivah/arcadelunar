// npm install --no-save @electric-sql/pglite@0.5.9 && node tests/database.mjs
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
const { PGlite } = await import(process.env.PGLITE_TEST_MODULE || "@electric-sql/pglite");
const db=new PGlite();
const actor = Object.fromEntries(["owner","alice","bob","sac","mod","tech"].map((name,i)=>[name,{id:"00000000-0000-4000-8000-"+String(i+1).padStart(12,"0"),email:name+"@test.invalid",name}]));
let checks=0;
async function rpc(name,action,payload={}){
 const a=actor[name];
 const r=await db.query("SELECT public.lunar_support($1,$2::uuid,$3,$4,$5::uuid,$6::jsonb) AS result",[action,a.id,a.email,a.name,actor.owner.id,JSON.stringify(payload)]);
 checks++;return r.rows[0].result;
}
async function denied(name,action,payload,status){
 await assert.rejects(()=>rpc(name,action,payload),e=>e.detail===String(status),action+" should return "+status);checks++;
}
try{
 await db.exec("CREATE ROLE anon;CREATE ROLE authenticated;CREATE ROLE service_role;CREATE SCHEMA storage;CREATE TABLE storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);");
 await db.exec(await readFile("supabase/01_instalar.sql","utf8"));
 assert.equal((await rpc("alice","me")).member.role,"cliente");
 assert.equal((await rpc("owner","me")).member.role,"admin");
 for(const [name,role]of [["sac","sac"],["mod","moderacao"],["tech","tecnico"]]){
  await rpc("owner","team_save",{email:actor[name].email,role});assert.equal((await rpc(name,"me")).member.role,role);
 }
 await denied("alice","team_get",{},403);
 await denied("owner","team_save",{email:actor.owner.email,role:"cliente"},400);
 const input={key:crypto.randomUUID(),title:"Falha ao iniciar a transmissão",description:"Não consigo iniciar a transmissão. Já reiniciei o aplicativo e testei outra conexão.",category:"lives",priority:"alta"};
 let d=await rpc("alice","ticket_create",input);const id=d.ticket.id;
 assert.equal(d.ticket.queue,"sac");assert.equal(d.ticket.requesterId,actor.alice.id);
 assert.equal((await rpc("alice","ticket_create",input)).ticket.id,id);
 assert.equal((await rpc("alice","tickets_list")).total,1);
 assert.equal((await rpc("bob","tickets_list")).tickets.length,0);
 await denied("bob","ticket_get",{id},403);
 await denied("alice","ticket_update",{id,version:1,queue:"tecnico",reason:"Não pode alterar a fila."},403);
 await denied("alice","message_create",{id,version:1,body:"Nota interna inválida",internal:true},403);
 await denied("sac","ticket_update",{id,version:1,queue:"tecnico",reason:"Não é permitido pular a moderação."},403);
 d=await rpc("sac","ticket_update",{id,version:d.ticket.version,assigneeId:actor.sac.id,status:"em_atendimento"});
 assert.equal(d.ticket.assigneeId,actor.sac.id);
 d=await rpc("sac","message_create",{id,version:d.ticket.version,body:"Contexto confidencial",internal:true});
 assert.equal(d.ticket.firstResponseAt,null);
 assert.equal((await rpc("alice","ticket_get",{id})).messages.length,0);
 d=await rpc("sac","message_create",{id,version:d.ticket.version,body:"Qual mensagem aparece na tela?",status:"aguardando",internal:false});
 assert.ok(d.ticket.firstResponseAt);
 const stale=d.ticket.version;
 d=await rpc("alice","message_create",{id,version:d.ticket.version,body:"Aparece uma falha ao iniciar.",internal:false});
 assert.equal(d.ticket.status,"em_atendimento");
 await denied("sac","message_create",{id,version:stale,body:"Não pode duplicar o histórico.",internal:false},409);
 assert.equal((await rpc("sac","ticket_get",{id})).messages.length,3);
 await denied("alice","upload_check",{id,internal:true},403);
 const c=await rpc("alice","upload_check",{id,internal:false});
 const fileId=crypto.randomUUID();
 const f=await rpc("alice","attachment_save",{id,version:c.version,fileId,storageKey:"tickets/"+id+"/"+fileId,name:"evidencia.png",mime:"image/png",size:100,internal:false});
 assert.equal(f.id,fileId);await denied("bob","attachment_get",{id:fileId},403);
 assert.equal((await rpc("alice","attachment_get",{id:fileId})).name,"evidencia.png");
 let check=await rpc("sac","upload_check",{id,internal:true});const internalFile=crypto.randomUUID();
 await rpc("sac","attachment_save",{id,version:check.version,fileId:internalFile,storageKey:"tickets/"+id+"/"+internalFile,name:"interno.pdf",mime:"application/pdf",size:150,internal:true});
 await denied("alice","attachment_get",{id:internalFile},403);
 assert.equal((await rpc("alice","ticket_get",{id})).attachments.length,1);
 d=await rpc("sac","ticket_get",{id});
 d=await rpc("sac","ticket_update",{id,version:d.ticket.version,queue:"moderacao",reason:"Verificar a restrição e o contexto da comunidade."});
 assert.equal(d.ticket.queue,"moderacao");assert.equal(d.ticket.assigneeId,null);
 const client=await rpc("alice","ticket_get",{id});assert.equal(client.events.some(e=>e.internal),false);assert.ok(client.events.some(e=>e.label.includes("Encaminhado")));
 await denied("sac","message_create",{id,version:d.ticket.version,body:"Resposta de outra equipe",internal:false},403);
 d=await rpc("mod","ticket_update",{id,version:d.ticket.version,queue:"tecnico",reason:"A análise indica que o problema exige correção no desenvolvimento."});
 assert.equal(d.ticket.queue,"tecnico");
 const outcomes=await Promise.allSettled([rpc("tech","message_create",{id,version:d.ticket.version,body:"Uma resposta concorrente.",internal:false}),rpc("tech","message_create",{id,version:d.ticket.version,body:"Outra resposta concorrente.",internal:false})]);
 assert.equal(outcomes.filter(r=>r.status==="fulfilled").length,1);
 assert.equal(outcomes.find(r=>r.status==="rejected").reason.detail,"409");
 d=await rpc("tech","ticket_get",{id});assert.equal(d.messages.length,4);
 d=await rpc("tech","message_create",{id,version:d.ticket.version,body:"Falha corrigida. Tente novamente.",status:"resolvido",internal:false});
 assert.equal(d.ticket.status,"resolvido");assert.ok(d.ticket.resolvedAt);
 d=await rpc("alice","ticket_update",{id,version:d.ticket.version,status:"aberto"});
 assert.equal(d.ticket.resolvedAt,null);assert.equal(d.ticket.queue,"tecnico");
 let own=await rpc("sac","ticket_create",{...input,key:crypto.randomUUID()});
 own=await rpc("owner","ticket_update",{id:own.ticket.id,version:own.ticket.version,queue:"moderacao",reason:"Avaliar esta solicitação pessoal de um atendente."});
 own=await rpc("sac","message_create",{id:own.ticket.id,version:own.ticket.version,body:"Contexto pessoal da minha solicitação.",internal:false,asRequester:true});
 assert.equal(own.messages.at(-1).authorRole,"cliente");
 await denied("sac","message_create",{id,version:d.ticket.version,body:"Tentativa de responder em nome de outro.",asRequester:true},403);
 for(const role of ["anon","authenticated"]){
  await db.exec("SET ROLE "+role);
  await assert.rejects(()=>db.query("SELECT * FROM public.lunar_tickets"));
  await assert.rejects(()=>db.query("SELECT public.lunar_support('me',NULL,NULL,NULL,NULL,'{}')"));
  await db.exec("RESET ROLE");checks+=2;
 }
 console.log("PASS: "+checks+" database checks, private notes/files, permissions, tier flow, idempotency and concurrent replies.");
}catch(e){console.error("Database verification failed:",e.message,e.detail ?? "",e.where ?? "");process.exitCode=1;}finally{await db.close();}
