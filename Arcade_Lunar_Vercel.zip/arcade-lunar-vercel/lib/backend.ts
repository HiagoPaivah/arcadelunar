import { cookies } from "next/headers";
export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export const ACCESS_COOKIE = "lunar_access";
export const REFRESH_COOKIE = "lunar_refresh";
export type AuthUser = { id: string; email: string; user_metadata?: { full_name?: string }; email_confirmed_at?: string };
export type AuthSession = { access_token: string; refresh_token: string; expires_in: number; user: AuthUser };
export function configuration() {
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "");
  const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
  const secretKey = process.env.SUPABASE_SECRET_KEY;
  if (!url || !publishableKey || !secretKey) throw new HttpError(503, "Configure as variáveis do Supabase indicadas no README para ativar contas e chamados reais.");
  return { url, publishableKey, secretKey };
}
export async function supabase(path: string, options: RequestInit = {}, privileged = false) {
  const c = configuration();
  const key = privileged ? c.secretKey : c.publishableKey;
  const headers = new Headers(options.headers);
  headers.set("apikey", key);
  if (privileged && key.startsWith("eyJ")) headers.set("Authorization", "Bearer " + key);
  if (options.body && typeof options.body === "string") headers.set("Content-Type", "application/json");
  try { return await fetch(c.url + path, { ...options, headers, cache: "no-store", signal: AbortSignal.timeout(15000) }); }
  catch { throw new HttpError(503, "Não foi possível conectar ao atendimento. Tente novamente."); }
}
export async function writeSession(session: AuthSession) {
  const jar = await cookies();
  const options = { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax" as const, path: "/" };
  jar.set(ACCESS_COOKIE, session.access_token, { ...options, maxAge: session.expires_in + 60 });
  jar.set(REFRESH_COOKIE, session.refresh_token, { ...options, maxAge: 30 * 86400 });
}
export async function clearSession() { const jar = await cookies(); jar.delete(ACCESS_COOKIE); jar.delete(REFRESH_COOKIE); }
async function userFromToken(token: string): Promise<AuthUser | null> {
  const response = await supabase("/auth/v1/user", { headers: { Authorization: "Bearer " + token } });
  if (response.status === 401 || response.status === 403) return null;
  if (!response.ok) throw new HttpError(503, "Não foi possível validar sua conta.");
  const user = await response.json() as AuthUser;
  return user.id && user.email ? user : null;
}
export async function refreshSession(): Promise<AuthSession | null> {
  const jar = await cookies(); const refresh = jar.get(REFRESH_COOKIE)?.value;
  if (!refresh) return null;
  const response = await supabase("/auth/v1/token?grant_type=refresh_token", { method: "POST", body: JSON.stringify({ refresh_token: refresh }) });
  if (!response.ok) return null;
  const session = await response.json() as AuthSession;
  if (!session.access_token || !session.refresh_token) return null;
  await writeSession(session); return session;
}
export async function sessionUser(allowRefresh = false): Promise<AuthUser | null> {
  const jar = await cookies(); const access = jar.get(ACCESS_COOKIE)?.value;
  let user = access ? await userFromToken(access) : null;
  if (!user && allowRefresh && jar.get(REFRESH_COOKIE)?.value) {
    const session = await refreshSession();
    if (session) user = await userFromToken(session.access_token);
  }
  return user;
}
export async function requireUser(): Promise<AuthUser> {
  const user = await sessionUser(true);
  if (!user) throw new HttpError(401, "Entre na sua conta para acessar os chamados.");
  return user;
}
export async function rpc<T>(action: string, user: AuthUser, payload: unknown = {}): Promise<T> {
  const ownerId = process.env.WORKSPACE_OWNER_ID?.trim() || null;
  if (ownerId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(ownerId)) throw new HttpError(503, "WORKSPACE_OWNER_ID deve conter o UUID da conta do administrador.");
  const response = await supabase("/rest/v1/rpc/lunar_support", { method: "POST", body: JSON.stringify({
    p_action: action, p_actor_id: user.id, p_email: user.email,
    p_name: user.user_metadata?.full_name || user.email.split("@")[0],
    p_owner_id: ownerId, p_payload: payload,
  }) }, true);
  const data = await response.json();
  if (!response.ok) {
    const status = Number(data.details);
    if ([400,401,403,404,409].includes(status)) throw new HttpError(status, data.message);
    if (data.code === "PGRST202" || data.code === "42P01") throw new HttpError(503, "Instale o arquivo supabase/01_instalar.sql no SQL Editor do Supabase.");
    throw new HttpError(500, "Não foi possível salvar ou carregar os dados. Confira a configuração do banco.");
  }
  return data as T;
}
export function assertOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) throw new HttpError(403, "Origem da solicitação não autorizada.");
}
export function json(data: unknown, status = 200) { return Response.json(data, { status, headers: { "Cache-Control": "private, no-store" } }); }
