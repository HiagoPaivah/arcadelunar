import { z } from "zod";
export const roles = ["cliente", "sac", "moderacao", "tecnico", "admin"] as const;
export type Role = typeof roles[number];
export const queues = ["sac", "moderacao", "tecnico"] as const;
export type Queue = typeof queues[number];
export const statuses = ["aberto", "em_atendimento", "aguardando", "resolvido"] as const;
export type Status = typeof statuses[number];
export const priorities = ["baixa", "normal", "alta", "urgente"] as const;
export type Priority = typeof priorities[number];
export const categories = ["conta", "lives", "comunidade", "bug", "sugestao"] as const;
export type Category = typeof categories[number];
export const roleLabels: Record<Role, string> = { cliente: "Cliente", sac: "SAC · Nível 1", moderacao: "Moderação · Nível 2", tecnico: "Técnico · Nível 3", admin: "Administrador" };
export const queueLabels: Record<Queue, string> = { sac: "SAC", moderacao: "Moderação", tecnico: "Técnico" };
export const statusLabels: Record<Status, string> = { aberto: "Aberto", em_atendimento: "Em atendimento", aguardando: "Aguardando cliente", resolvido: "Resolvido" };
export const priorityLabels: Record<Priority, string> = { baixa: "Baixa", normal: "Normal", alta: "Alta", urgente: "Urgente" };
export const categoryLabels: Record<Category, string> = { conta: "Conta e acesso", lives: "Lives e transmissão", comunidade: "Comunidade e regras", bug: "Problema técnico", sugestao: "Sugestão" };
export type Member = { id: string; email: string; name: string; role: Role; createdAt: number };
export type Ticket = {
  id: number; key: string; requesterId: string; requesterName: string; requesterEmail: string;
  title: string; description: string; category: Category; priority: Priority; status: Status; queue: Queue;
  assigneeId: string | null; assigneeName: string | null; createdAt: number; updatedAt: number;
  firstResponseAt: number | null; resolvedAt: number | null; version: number;
};
export type Message = { id: string; ticketId: number; authorId: string; authorName: string; authorRole: Role; body: string; internal: boolean; createdAt: number };
export type TicketEvent = { id: string; ticketId: number; actorId: string; actorName: string; label: string; detail: string | null; internal: boolean; createdAt: number };
export type Attachment = { id: string; ticketId: number; name: string; mime: string; size: number; internal: boolean; createdAt: number; url?: string };
export type TicketDetail = { ticket: Ticket; messages: Message[]; events: TicketEvent[]; attachments: Attachment[] };
export const ticketInput = z.object({
  key: z.string().uuid(), title: z.string().trim().min(5, "Use pelo menos 5 caracteres no assunto.").max(140),
  description: z.string().trim().min(15, "Conte o que aconteceu em pelo menos 15 caracteres.").max(10000),
  category: z.enum(categories), priority: z.enum(priorities).default("normal"),
});
export const updateInput = z.object({
  version: z.number().int().positive(), status: z.enum(statuses).optional(), priority: z.enum(priorities).optional(),
  category: z.enum(categories).optional(), queue: z.enum(queues).optional(),
  assigneeId: z.string().max(200).nullable().optional(), reason: z.string().trim().max(2000).optional(), asRequester: z.boolean().default(false),
});
export const messageInput = z.object({ version: z.number().int().positive(), body: z.string().trim().min(1, "Escreva uma mensagem.").max(10000), internal: z.boolean().default(false), status: z.enum(statuses).optional(), asRequester: z.boolean().default(false) });
export const permissionInput = z.object({ email: z.string().trim().toLowerCase().email(), role: z.enum(roles) });
export function isStaff(role: Role) { return role !== "cliente"; }
export function canRead(member: Member, ticket: Pick<Ticket, "requesterId">) { return isStaff(member.role) || ticket.requesterId === member.id; }
export function canHandle(member: Member, ticket: Pick<Ticket, "queue">) { return member.role === "admin" || member.role === ticket.queue; }
export function canEscalate(member: Member, from: Queue, to: Queue) {
  if (!canHandle(member, { queue: from }) || from === to) return false;
  if (member.role === "admin") return true;
  return (from === "sac" && to === "moderacao") || (from === "moderacao" && (to === "tecnico" || to === "sac")) || (from === "tecnico" && to === "sac");
}
export function canAssign(member: Member, queue: Queue) { return member.role === "admin" || member.role === queue; }
export function nextQueue(queue: Queue): Queue | null { return queue === "sac" ? "moderacao" : queue === "moderacao" ? "tecnico" : null; }
export function ticketNumber(id: number) { return `AL-${String(id + 1000).padStart(4, "0")}`; }
export function firstName(name: string) { return name.includes("@") ? name.split("@")[0] : name.split(" ")[0]; }
export function initials(name: string) { return name.split(/[\s@._-]+/).filter(Boolean).slice(0, 2).map(p => p[0]).join("").toUpperCase(); }
export const MAX_FILE_BYTES = 3 * 1024 * 1024;
export const allowedMimes = ["image/png", "image/jpeg", "image/webp", "application/pdf"];
