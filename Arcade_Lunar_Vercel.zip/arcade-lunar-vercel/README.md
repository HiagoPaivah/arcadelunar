# Arcade Lunar — versão para Vercel

Portal responsivo de suporte, adaptado para **Next.js + Supabase**. Inclui contas, recuperação de senha, banco PostgreSQL, anexos privados, chamados, notas internas, histórico, filtros, relatórios e permissões por equipe.

Todo chamado começa no **SAC**, que encaminha para **moderação** e, quando necessário, para o **técnico**. Clientes acessam seus próprios chamados. O botão **Ver demonstração** usa exemplos separados dos dados reais.

## 1. Instale o banco

1. Extraia o ZIP.
2. Crie um projeto em [Supabase](https://supabase.com/dashboard).
3. Abra **SQL Editor** no projeto.
4. Copie todo o arquivo `supabase/01_instalar.sql` e execute.

Esse SQL instala as tabelas, as regras e o bucket privado `lunar-attachments`. Pode ser executado novamente sem apagar chamados. Ele cria a estrutura; os dados da publicação anterior não são importados automaticamente.

## 2. Crie sua conta de administrador

No Supabase, abra **Authentication > Users > Add user**. Crie sua conta com seu e-mail e uma senha escolhida por você. Confirme essa conta pelo painel ou pelo e-mail e copie seu **User UID/UUID**.

Esse UUID será `WORKSPACE_OWNER_ID`. Não existe senha padrão. Depois do login, use **Equipe e permissões** para autorizar outras pessoas por e-mail como SAC, moderadores ou técnicos. Elas criam suas próprias contas em **Cadastre-se**.

## 3. Cadastre as variáveis na Vercel

Use **Settings > Environment Variables**:

| Nome | Valor |
| --- | --- |
| `SUPABASE_URL` | URL do projeto, como `https://seu-projeto.supabase.co` |
| `SUPABASE_PUBLISHABLE_KEY` | Chave `sb_publishable_...` |
| `SUPABASE_SECRET_KEY` | Chave `sb_secret_...`, somente para o servidor |
| `WORKSPACE_OWNER_ID` | UUID da sua conta em Authentication > Users |

Copie URL e chaves em **Connect** e **Settings > API Keys**, no Supabase. O código também aceita chaves legadas `anon` e `service_role` nesses dois campos, quando existentes.

A chave secreta não deve receber o prefixo `NEXT_PUBLIC_` nem ser colocada no GitHub. O arquivo `.env.example` contém exemplos; preencha os valores reais nas configurações da Vercel.

Selecione o ambiente **Production** e, se usar, **Preview**. Após alterar uma variável, faça um novo deploy.

## 4. Publique na Vercel

### Pelo GitHub

1. Crie um repositório no GitHub.
2. Envie os arquivos de dentro da pasta `arcade-lunar-vercel`, onde está `package.json`.
3. Em [Vercel > New Project](https://vercel.com/new), importe esse repositório.
4. Selecione **Framework Preset: Next.js**.
5. A **Root Directory** deve ser a pasta que contém `package.json`.
6. Use **Build Command: `npm run build`** e **Install Command: `npm ci`**.
7. Deixe **Output Directory** no padrão do Next.js.
8. Cadastre as quatro variáveis e clique em **Deploy**.

### Pelo terminal

Instale Node.js 22 ou mais recente. Dentro da pasta extraída, execute:

```bash
npm ci
npx vercel
```

Siga a conexão à sua conta. Depois de cadastrar as variáveis no projeto, publique a produção:

```bash
npx vercel --prod
```

## 5. Configure confirmação e recuperação de senha

Depois de receber o endereço da Vercel, abra **Authentication > URL Configuration** no Supabase:

- **Site URL:** endereço principal do site.
- **Redirect URLs:** adicione `https://SEU-SITE.vercel.app/login` e `https://SEU-SITE.vercel.app/reset-password`.

Se usar domínio próprio, adicione as mesmas rotas nesse domínio. Para testes locais, adicione `http://localhost:3000/login` e `http://localhost:3000/reset-password`.

Mantenha o provedor **Email** e a confirmação de e-mail habilitados. Configure um remetente SMTP no Supabase para enviar os e-mails aos usuários de produção.

## 6. Confira o atendimento

1. Entre com sua conta de administrador.
2. Abra o **Portal do cliente** e crie um chamado.
3. Volte à **Área de atendimento**: a solicitação estará no SAC.
4. Responda, salve uma nota interna e encaminhe com um motivo.
5. Confira moderação e técnico; resolva e reabra pelo portal do cliente.
6. Crie uma segunda conta para conferir que ela não vê os chamados da primeira.

Anexos: PNG, JPG, WEBP ou PDF, até **3 MB por arquivo**, até 3 na abertura e 10 por chamado. O tamanho foi ajustado para os limites de requisição da Vercel. Os arquivos são baixados pelo portal após verificar o acesso.

As listagens mostram os 200 chamados mais recentes e um trecho da descrição. A conversa exibe o relato completo. Se houver mais chamados, o site informa a seleção usada pelos indicadores.

## Rodar no computador

Copie `.env.example` para `.env.local` e preencha os quatro valores:

```bash
npm ci
npm run dev
```

Abra `http://localhost:3000`. Para verificar e compilar:

```bash
npm run check
npm test
npm run build
```

O teste opcional do SQL usa PostgreSQL em memória:

```bash
npm install --no-save @electric-sql/pglite@0.5.9
node tests/database.mjs
```

A compilação de produção e os testes das regras do banco foram executados na preparação do ZIP. A conexão ao seu projeto Supabase deve ser conferida após preencher as variáveis. Nenhuma credencial real acompanha o arquivo.

## Arquivos principais

| Arquivo | Função |
| --- | --- |
| `app/desk.tsx` | Painel, navegação e chamados |
| `app/ticket-dialogs.tsx` | Formulários e conversa |
| `app/sections.tsx` | Ajuda, relatórios e equipes |
| `app/globals.css` | Visual responsivo |
| `app/login` e `app/reset-password` | Contas e recuperação |
| `app/api/support` e `app/api/auth` | APIs de atendimento e contas |
| `lib/backend.ts` | Conexão ao Supabase pelo servidor |
| `supabase/01_instalar.sql` | Instalação do banco e bucket |

## Referências

- [Next.js na Vercel](https://vercel.com/docs/frameworks/full-stack/nextjs)
- [Variáveis de ambiente](https://vercel.com/docs/environment-variables)
- [Limites das funções](https://vercel.com/docs/functions/limitations)
- [Chaves do Supabase](https://supabase.com/docs/guides/getting-started/api-keys)
- [Login por senha](https://supabase.com/docs/guides/auth/passwords)
- [Funções do banco](https://supabase.com/docs/guides/database/functions)
- [Arquivos privados](https://supabase.com/docs/guides/storage/buckets/fundamentals)
